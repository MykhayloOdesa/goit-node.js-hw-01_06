# goit-node.js-hw-01_06

# HW#1:

# yargs /

1. added package - https://prnt.sc/QnyKQ2L2gSXp
2. action list - https://prnt.sc/5Rw7vaP_rE7A
3. action get - https://prnt.sc/7sklDON0o3bw
4. action add - https://prnt.sc/dvDbH5l7p5yu
5. action remove - https://prnt.sc/GR5X8Gv2n90m

# commander /

1. added package - https://prnt.sc/gJLN1TVlUdIX
2. action list - https://prnt.sc/EydQZWqvxuaB
3. action get - https://prnt.sc/hzfBUpb9Z718
4. action add - https://prnt.sc/O1ppDpNh4nuN
5. action remove - https://prnt.sc/jqTvf2jyjUkt
